 class Stack
    def initialize
      # create ivar to store stack here!
       @stack  = Array.new
    end

    def push(el)
      # adds an element to the stack
      @stack.push(el)
    end

    def pop
      # removes one element from the stack
      @stack.pop
    end

    def peek
      # returns, but doesn't remove, the top element in the stack
      @stack.last
    end
  end

  s = Stack.new
  s.push(1)
#   p s.peek

   class Queue
    def initialize
     
       @Queue  = Array.new
    end

    def enqueue(el)
      # adds an element to the queue
      @Queue.push(el)
    end

    def dequeue
      # removes one element from the queue
      @Queue.shift
    end

    def peek
      # returns, but doesn't remove, the top element in the queue
      @Queue.first
    end
  end
require 'byebug'
  class Map
    attr_accessor :my_map
       
     def initialize
       @my_map  = Array.new{Array.new}
     end

    def set(key,value)
        debugger
        @my_map << [key,value] if my_map.empty?
        @my_map.each do |sub_arr|
         if sub_arr.include?(key)
                sub_arr[0] = key
                sub_arr[1] = value
         else
            @my_map << [key,value]
         end 
        end 
        
    end 
    def get(key)
        @my_map.each do |sub_arr|
            if sub_arr.include?(key)
                return sub_arr
            end 
        end 
    end 
    def delete(key)
        @my_map.each do |sub_arr|
            if sub_arr.include?(key)
                @my_map.delete(sub_arr)
            end 
        end 
    end 

  end 

  m = Map.new
  m.set(1,2)
  p m.get(1)
  p 